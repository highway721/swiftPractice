import UIKit

var str = "Hello, playground"
print(123 == 456)
print(123 != 456)
print(123<=456)
print("1\n2\n3")
let result = 7+9
print("result is \(result)")
let s1 = "123"
let i1 = Int(s1)
//print(i1)
//let s2 = "abc"
//let i2 = Int(s2)
//print(i2)
let string1 = "abc"
let string2 = "def"
string1 == string2
string1 + string2
//let none = Optional<Int>.none
//print(none)
//let some = Optional<Int>.some(1)
//print(some)
print("?はOptional<Wrappedg型>を示す")
let a: Int? = 1
let b: Int? = 1
a!+b!
let optionalA = Optional("a")
if optionalA != nil{
    print("Hello")
}
let optionalDouble = Optional(1.0)
let optionalIsInfinite: Bool?
if let double = optionalDouble{
    optionalIsInfinite = double.isInfinite
}else{
    optionalIsInfinite = nil
}
print(String(describing: optionalIsInfinite))
let optionalRange = Optional(0..<10)
let containSeven = optionalRange?.contains(7)
print(containSeven)
let a1 = Optional(17)
let b1 = a1.map({value in value * 2})
print(b1)
var integers = [1,2,3,4]
print(integers[1])
integers[1] = 10
print(integers[1])
integers.append(20)
print(integers[4])
integers.insert(30, at: 0)
for i in 0...5{
    print(integers[i])
}
var dictionary = ["Key" : 1]
//let value = dictionary["Key"]
//print(value)
dictionary["Key2"] = 2
dictionary
dictionary["Key2"] = nil
dictionary
let range = 1..<4
for value in range{
    print(value)
}
let range2 = 1...4
for value in range2{
    print(value)
}
range2.contains(5)
let array = [1,2,3,4,5,6]
let filtered = array.filter({element in element % 2 == 0})
filtered
let doubled = array.map({element in element * 2})
doubled
array.isEmpty
array.count
array.first
let optionalAA = Optional("A")
let optionalBB = Optional("B")
if let a = optionalAA, let b = optionalBB{
    print("Nice")
}else{
    ("There is no numbers")
}
let a2: Any = 1
if let int = a2 as? Int{
    print("The value is Int Type\(int)")
}
//print(int)
func someFunction(){
    let value = -1
    guard value>=0 else{
    //条件式がfalseの場合に実行される文
    print("0未満の値です")
    return
    }
}

someFunction()
func printIfpositive(_ a: Int){
    guard a > 0 else {
        return
    }
    print(a)
}
printIfpositive(1)

func someFunction2(){
    let a: Any = 1
    
    guard let int = a as? Int else{
    //条件式がfalseの場合に実行される文
    print("a is not Int type")
    return
    }
    // int-type can use after guard
    print("The value is Int Type\(int)")
}
print("_____________________________________________")
// 2つのInt？型の値を受け取り、両方とも値を持っていればその和を返し、どちらかが値を持っていなければNillを返すプログラム
//Guard文

func add(_ optionalA: Int?, _ optionalB: Int?) -> Int?{
guard let a = optionalA else{
    print("No value inside at no1 parameter")
    return nil
    }
    guard let b = optionalB else{
    print("No value inside at no2 parameter")
    return nil
    }
    return a + b
}
print(add(1, 2))
print("_____________________________________________")
let a3 = 1
switch a {
case 1:
    print("we can excute")
    fallthrough
case 2:
   print("Case2")
default:
    print("default")
}
print("_____________________________________________")
let dictionary2 = ["a":1, "b":2, "c":3]
for (key, value) in dictionary2{
    print("Key is \(key), and value is  \(value)")
}
print("_____________________________________________")
var a4 = 1
while a4 < 4{
    print(a4)
    a4 = a4 + 1
}
var a5 = 1
while a5 < 1{
    print(a5)
    a5 = a5 + 1
}
print("_____________________________________________")
var a6 = 1
repeat{
    print(a6)
    a6 += 1
}while a6 < 1
print("_____________________________________________")
var containTwoDivide = false
let array2 = [1,2,3,4]
for element in array{
    if element % 2 == 0{
        containTwoDivide = true
        continue
    }
    print(element)
}
print("ContainTwoDivide: \(containTwoDivide)")
print("_____________________________________________")
let optioanlA2 = Optional(4)
switch optioanlA2{
case let a?:
    print(a)
default:
    print("nil")
}
print("_____________________________________________")
let any: Any = 1
switch any {
case is String:
    print("This is String")
case is Int:
     print("This is Int")
default:
    print("Default")
}
print("_____________________________________________")
let value = 9
if case 1...10 = value{
    print("This value is inside of 1~10")
}
print("_____________________________________________")
let array3 = [1,2,3,4]
for case 2...3 in array{
    print("value is among 2-3")
}
print("_____________________________________________")

